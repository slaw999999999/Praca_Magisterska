#importing library
import numpy as np
import matplotlib.pyplot as plt
#datasets
days = [1,2,3,4,5]
profit = [120,140,138,162,185]
#scatter plot for the dataset
plt.scatter(days, profit)
plt.show()