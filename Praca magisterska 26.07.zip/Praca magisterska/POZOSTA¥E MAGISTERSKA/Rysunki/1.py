import pandas as pd
 
sample_timeseries_data = {
 
    'Date': ['2022-01-25', '2022-02-25',
             '2022-03-25', '2022-04-25',
             '2022-05-25', '2022-06-25',
             '2022-07-25', '2022-08-25',
             '2022-09-25', '2022-10-25',
             '2022-11-25', '2022-12-25',
             '2023-01-25', '2023-02-25',
             '2023-03-25', '2023-04-25'],
 
    'A': [130, 120, 512, 713,
          641, 764, 997, 878,
          940, 974, 899, 954,
          1105, 1189, 1000, 900],

}
dataframe = pd.DataFrame(
  sample_timeseries_data,columns=[
    'Date', 'A'])

dataframe["Date"] = dataframe["Date"].astype("datetime64")
 
dataframe = dataframe.set_index("Date")

import matplotlib.pyplot as plt
 
plt.style.use("fivethirtyeight")
 
plt.figure(figsize=(14, 12))
 
# Labelling the axes and setting
# a title
#plt.xlabel("Data")
#plt.ylabel("Cena")
 
plt.plot(dataframe["A"])

plt.show()