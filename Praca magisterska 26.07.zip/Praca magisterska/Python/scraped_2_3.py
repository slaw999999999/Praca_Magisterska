import requests
import pandas as pd
from datetime import datetime

url = "https://api.cryptowat.ch/markets/binance/btceur/ohlc"
params = {
    "after": 1636588800,
    "before": 1668124800,
    "periods": 7200
}

response = requests.get(url, params=params)
data = response.json()

# Pobranie danych z odpowiedzi API
raw_data = data["result"]["7200"]

# Utworzenie list dla każdej kolumny danych
timestamps = [entry[0] for entry in raw_data]
open_prices = [entry[1] for entry in raw_data]
high_prices = [entry[2] for entry in raw_data]
low_prices = [entry[3] for entry in raw_data]
close_prices = [entry[4] for entry in raw_data]
volumes = [entry[5] for entry in raw_data]
quote_volumes = [entry[6] for entry in raw_data]

# Konwersja timestampów na daty
dates = [datetime.fromtimestamp(timestamp) for timestamp in timestamps]

# Utworzenie tabeli przy użyciu biblioteki pandas
df = pd.DataFrame({
    "Date": dates,
    "Open": open_prices,
    "High": high_prices,
    "Low": low_prices,
    "Close": close_prices,
    "Volume": volumes,
    "Quote Volume": quote_volumes
})

# Wyświetlenie tabeli
print(df)