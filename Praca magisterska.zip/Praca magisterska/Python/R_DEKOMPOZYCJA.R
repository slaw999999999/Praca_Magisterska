library(x12)
data <- read.csv("C:/Users/Admin/Desktop/Praca magisterska/Python/RTV-AGD_awa.csv")
data$DATA <- as.Date(data$DATA)
ts_data <- ts(data$WARTOSC.TYS., frequency = 7, start = c(year(data$DATA[1]), month(data$DATA[1])))
decomposition <- decompose(ts_data, "multiplicative")
plot(decomposition)

calls %>% mstl() %>%
  autoplot() + xlab("Week")
install.packages("ggplot2")
library(ggplot2)
mstl(taylor) %>% autoplot()
mstl(, lambda = "auto") %>% autoplot()
